<?php
/**
 * Plugin Name: Narasix Core
 * Description: Core plugin for Narasix theme.
 * Plugin URI:  https://hidunks.com/
 * Version:     1.0.0
 * Author:      hidunks
 * Author URI:  https://hidunks.com/
 * Text Domain: narasix-core
 */

if ( !defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Main Narasix Core Class
 *
 * The init class that runs the Narasix Core plugin.
 * Intended To make sure that the plugin's minimum requirements are met.
 *
 * You should only modify the constants to match your plugin's needs.
 *
 * Any custom code should go inside Plugin Class in the plugin.php file.
 * @since 1.0.0
 */
final class Narasix_Core {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {

		// Load translation
		add_action( 'init', array( $this, 'i18n' ) );

		// Init Plugin
		add_action( 'plugins_loaded', array( $this, 'init' ) );
	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function i18n() {
		load_plugin_textdomain( 'narasix-core' );
	}

	/**
	 * Initialize the plugin
	 *
	 * Validates that Elementor is already loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed include the plugin class.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function init() {

		// Check for required Elementor version
		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
				add_action( 'admin_notices', array( $this, 'admin_notice_minimum_elementor_version' ) );
				return;
			}
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', array( $this, 'admin_notice_minimum_php_version' ) );
			return;
		}

		// Add new Elementor widget category
		add_action( 'elementor/elements/categories_registered', array( $this, 'add_elementor_widget_categories' ), 0 );

		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once( plugin_dir_path( __FILE__ ) . 'inc/elementor/narasix-elementor.php' );
		
		// Add theme's custom widgets
		self::add_theme_customizer();
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'narasix-core' ),
			'<strong>' . esc_html__( 'Narasix Core', 'narasix-core' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'narasix-core' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'narasix-core' ),
			'<strong>' . esc_html__( 'Narasix Core', 'narasix-core' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'narasix-core' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'narasix-core' ),
			'<strong>' . esc_html__( 'Narasix Core', 'narasix-core' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'narasix-core' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Add new Elementor widget category
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function add_elementor_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'narasix',
			[
				'title' => __( 'Narasix', 'narasix-core' ),
				'icon' => 'fa fa-plug',
			]
		);

	}

	/**
	 * Add theme's custom widgets
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function add_theme_customizer() {
		include_once( plugin_dir_path( __FILE__ ) . 'inc/nsix-categories-widget.php' );
		include_once( plugin_dir_path( __FILE__ ) . 'inc/nsix-recent-post-widget.php' );
	}

	/**
	 * Add social share buttons for single post
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public static function post_social_share( $args ) {
		// Exit if Narasix theme isn't active
		if ( !function_exists( 'narasix_get_option' ) && !function_exists( 'narasix_svg_icon' ) ) {
			return;
		}

		$default_networks = [
			'facebook',
			'twitter',
			'pinterest',
			'telegram.me',
			'gmail',
			'email',
			'line.me',
			'vk',
			'skype',
			'tumblr',
		];
		$networks = narasix_get_option( 'single_social_share_selection', $default_networks );
		$url = urlencode( $args['url'] );
		$title = urlencode( $args['title'] );
		$image = urlencode( $args['image'] );
		$desc = urlencode( $args['desc'] );

		$text = $title;
		if( $desc ) {
			$text .= '%20%3A%20';	# This is just this, " : "
			$text .= $desc;
		}

		$names = [
			'whatsapp' => 'whatsapp',
			'blogger' => 'Blogger',
			'digg' => 'Digg',
			'email' => esc_html__( 'Email', 'narasix' ),
			'evernote' => 'Evernote',
			'getpocket' => 'Pocket',
			'facebook' => 'Facebook',
			'flipboard' => 'Flipboard',
			'gmail' => 'Gmail',
			'instapaper' => 'Instapaper',
			'line.me' => 'LINE',
			'linkedin' => 'LinkedIn',
			'pinterest' => 'Pinterest',
			'reddit' => 'Reddit',
			'skype' => 'Skype',
			'telegram.me' => 'Telegram',
			'tumblr' => 'Tumblr',
			'twitter' => 'Twitter',
			'vk' => 'VK',
			'weibo' => 'Weibo',
			'xing' => 'XING',
			'yahoo' => 'Yahoo',
		];

		$icons = [
			'whatsapp' => 'whatsapp',
			'blogger' => 'blogger',
			'digg' => 'digg',
			'email' => 'mail',
			'evernote' => 'evernote',
			'getpocket' => 'pocket',
			'facebook' => 'facebook',
			'flipboard' => 'flipboard',
			'gmail' => 'gmail',
			'instapaper' => 'instapaper',
			'line.me' => 'line',
			'linkedin' => 'linkedin',
			'pinterest' => 'pinterest',
			'reddit' => 'reddit',
			'skype' => 'skype',
			'telegram.me' => 'telegram',
			'tumblr' => 'tumblr',
			'twitter' => 'twitter',
			'vk' => 'vk',
			'weibo' => 'sinaweibo',
			'xing' => 'xing',
			'yahoo' => 'yahoo',
		];

		$urls = [
			'whatsapp'=>'whatsapp://send?text=' . $url . '&n=' . $title . '&t=' . $desc,
			'blogger'=>'https://www.blogger.com/blog-this.g?u=' . $url . '&n=' . $title . '&t=' . $desc,
			'digg'=>'http://digg.com/submit?url=' . $url . '&title=' . $text,
			'email'=>'mailto:?subject=' . $title . '&body=' . $desc,
			'evernote'=>'http://www.evernote.com/clip.action?url=' . $url . '&title=' . $text,
			'getpocket'=>'https://getpocket.com/edit?url=' . $url,
			'facebook'=>'http://www.facebook.com/sharer.php?u=' . $url,
			'flipboard'=>'https://share.flipboard.com/bookmarklet/popout?v=2&title=' . $text . '&url=' . $url,
			'gmail'=>'https://mail.google.com/mail/?view=cm&su=' . $title . '&body=' . $url,
			'google.bookmarks'=>'https://www.google.com/bookmarks/mark?op=edit&bkmk=' . $url . '&title=' . $title . '&annotation=' . $text,
			'instapaper'=>'http://www.instapaper.com/edit?url=' . $url . '&title=' . $title . '&description=' . $desc,
			'line.me'=>'https://lineit.line.me/share/ui?url=' . $url . '&text=' . $text,
			'linkedin'=>'https://www.linkedin.com/shareArticle?mini=true&url=' . $url . '&title=' . $title . '&summary=' . $text,
			'hacker.news'=>'https://news.ycombinator.com/submitlink?u=' . $url . '&t=' . $title,
			'pinterest'=>'http://pinterest.com/pin/create/button/?url=' . $url ,
			'reddit'=>'https://reddit.com/submit?url=' . $url . '&title=' . $title,
			'skype'=>'https://web.skype.com/share?url=' . $url . '&text=' . $text,
			'telegram.me'=>'https://t.me/share/url?url=' . $url . '&text=' . $text,
			'tumblr'=>'https://www.tumblr.com/widgets/share/tool?canonicalUrl=' . $url . '&title=' . $title . '&caption=' . $desc,
			'twitter'=>'https://twitter.com/intent/tweet?url=' . $url . '&text=' . $text,
			'vk'=>'http://vk.com/share.php?url=' . $url . '&title=' . $title . '&comment=' . $desc,
			'weibo'=>'http://service.weibo.com/share/share.php?url=' . $url . '&appkey=&title=' . $title . '&pic=&ralateUid=',
			'xing'=>'https://www.xing.com/spi/shares/new?url=' . $url,
			'yahoo'=>'http://compose.mail.yahoo.com/?subject=' . $title . '&body=' . $text,
		];

		foreach ( $networks as $network ) {
				if ( ( array_key_exists( $network, $urls ) ) && ( array_key_exists( $network, $icons ) ) && ( array_key_exists( $network, $names ) ) ) {
						echo '<li class="share-to">';
						echo '<a href="' . $urls[$network] .'" class="social-share" target="_blank">' . narasix_svg_icon( [ 'icon' => $icons[$network] ] ) . '<span class="social-item-name">' . $names[$network] . '</span></a>';
						echo '</li>';
				}
		} 

	}
	
}

// Instantiate Narasix_Core.
new Narasix_Core();