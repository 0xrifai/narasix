<?php
/*
 * Display the Posts List
 */

class nsix_recent_posts_widget extends WP_Widget { 
  public function __construct()
	{
		parent::__construct('nsix_recent_posts_widget', ' Narasix - ' . esc_html__('Recent Posts', 'narasix-core'), array('description' => esc_html__('Display the posts slider in your sidebar or footer', 'narasix-core'), 'classname' => 'nsix-post-list-widget'));	
	}
  
  public function widget( $args, $instance ) {
    $title = apply_filters( 'widget_title', $instance['title'] );
    $num_posts = ! empty( $instance['num_posts'] ) ? $instance['num_posts'] : 5;
    $template = ! empty( $instance['template'] ) ? $instance['template'] : 'default';

    echo $args['before_widget'];
    if ( ! empty( $title ) ) {
        echo $args['before_title'] . $title . $args['after_title'];
    }

    narasix_get_template_part('template-parts/widgets/recent-post/'.$template, NULL, 
    array(
      'num_posts' => $num_posts
    ));

    wp_reset_postdata();

    echo $args['after_widget'];
  }

  public function form( $instance ) {
    if ( isset( $instance[ 'title' ] ) ) {
        $title = $instance[ 'title' ];
    }
    else {
        $title = __( 'Recent Posts', 'narasix-core' );
    }

    if ( isset( $instance[ 'num_posts' ] ) ) {
        $num_posts = $instance[ 'num_posts' ];
    }
    else {
        $num_posts = 5;
    }
    $template = ! empty( $instance['template'] ) ? $instance['template'] : 'default';
    ?>
    <p>
        <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label> 
        <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
    </p>
    <p>
    <label for="<?php echo $this->get_field_id( 'num_posts' ); ?>"><?php _e( 'Number of Posts to Display:' ); ?></label> 
        <input class="widefat" id="<?php echo $this->get_field_id( 'num_posts' ); ?>" name="<?php echo $this->get_field_name( 'num_posts' ); ?>" type="number" min="1" step="1" value="<?php echo esc_attr( $num_posts ); ?>">
    </p>
    <p>
        <label for="<?php echo $this->get_field_id( 'template' ); ?>"><?php _e( 'Template:' ); ?></label>
        <select class="widefat" id="<?php echo $this->get_field_id( 'template' ); ?>" name="<?php echo $this->get_field_name( 'template' ); ?>">
            <option value="default" <?php selected( $template, 'default' ); ?>><?php _e( 'Default', 'narasix-core' ); ?></option>
            <option value="template-1" <?php selected( $template, 'template-1' ); ?>><?php _e( 'Template 1', 'narasix-core' ); ?></option>
            <option value="template-2" <?php selected( $template, 'template-2' ); ?>><?php _e( 'Template 2', 'narasix-core' ); ?></option>
            <option value="template-3" <?php selected( $template, 'template-3' ); ?>><?php _e( 'Template 3', 'narasix-core' ); ?></option>
        </select>
    </p>
    <?php
  }

  public function update( $new_instance, $old_instance ) {
    $instance = array();
    $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
    $instance['num_posts'] = ( ! empty( $new_instance['num_posts'] ) ) ? strip_tags( $new_instance['num_posts'] ) : '';
    $instance['template'] = ( ! empty( $new_instance['template'] ) ) ? strip_tags( $new_instance['template'] ) : 'default';
    return $instance;
  }

}

// Register Widget.
if ( ! function_exists( 'register_recent_posts_widget' ) ) {
	function register_recent_posts_widget() {
		register_widget( 'nsix_recent_posts_widget' );
	}

	add_action( 'widgets_init', 'register_recent_posts_widget' );
}
