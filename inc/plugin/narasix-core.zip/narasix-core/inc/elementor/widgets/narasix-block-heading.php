<?php
namespace NarasixCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Block_Heading extends Widget_Base {

	use \NarasixCore\Traits\Helper;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'narasix-block-heading';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Narasix Block Heading', 'narasix-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-animated-headline';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'narasix' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'narasix-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'heading_section',
			[
				'label' => esc_html__( 'Heading', 'narasix-core' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label' => esc_html__( 'Heading', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'subheading',
			[
				'label' => esc_html__( 'Subheading', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'heading_url',
			[
				'label' => esc_html__( 'Heading URL', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::URL,
			]
		);

		$this->add_control(
			'heading_url_text',
			[
				'label' => esc_html__( 'Heading URL text', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'View more', 'narasix-core' ),
			]
		);

		$this->add_control(
			'block_heading_color_control',
			[
					'label' => __( 'Heading Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
							'{{WRAPPER}} .meta-title-block' => 'color: {{VALUE}};',
					],
			]
		);

		$this->add_control(
			'list_color_control',
			[
					'label' => __( 'List Heading Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#e5e7eb',
					'selectors' => [
							'{{WRAPPER}} .border-l-8' => 'border-color: {{VALUE}};',
					],
			]
		);

		$this->add_control(
			'block_read_more_color_control',
			[
					'label' => __( 'Read more Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
							'{{WRAPPER}} .btn-animation' => 'color: {{VALUE}};',
					],
			]
		);

		$this->add_control(
			'block_prev_next_color_control',
			[
					'label' => __( 'Heading Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
							'{{WRAPPER}} .button--next .icons svg' => 'fill: {{VALUE}};',
							'{{WRAPPER}} .button--prev .icons svg,' => 'fill: {{VALUE}};',
					],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'label' => __( 'Font', 'narasix-core' ),
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .meta-title-block',
			]
		);
	

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		// Get widget settings
		$settings = $this->get_settings_for_display();

        $this->add_render_attribute(
            'section_wrapper',
            [
                'id' => 'nsix-section-heading-' . esc_attr( $this->get_id() ),
                'class' => [
                    'nsix-section-heading',
                ],
            ]
        );

        if ( $settings['heading'] ) {
        	switch ( $settings['heading_width']) {
        		case 'default':
        		default:
        			$container_class = 'container';
        			break;

        		case 'wide':
        			$container_class = 'container-wide';
        			break;

        		case 'fullwidth':
        			$container_class = 'container-fullwidth';
        			break;
        	}

        	echo '<div ' . $this->get_render_attribute_string( 'section_wrapper' ) . '>';
        		echo '<div class="' . esc_attr( $container_class ) . '">';

        ?>
        			<div class="flex justify-between items-center my-4 md:my-6">
		                <div class="border-l-8 pl-3">
		                    <h4 class="text-xl font-semibold sm:text-2xl">
		                        <?php
		                        echo wp_kses_post( $settings['heading'] );
		                        ?>
		                    </h4>

		                    <?php
		                    if ( $settings['subheading'] ) {
		                        echo '<div class="text-base opacity-60">';
		                        echo wp_kses_post( $settings['subheading'] );
		                        echo '</div>';
		                    }
		                    ?>
		                </div>

		                <div>
		                    <?php
		                    if ( $settings['heading_url']['url'] && $settings['heading_url_text'] ) {
		                    ?>
		                        <a class="st-btn-icon-animation-on-hover" href="<?php echo esc_url( $settings['heading_url']['url'] ); ?>"<?php
		                            if( $settings['heading_url']['is_external'] ) {
		                                if( $settings['heading_url']['nofollow'] ) {
		                                    echo ' target="_blank" rel="noopener noreferrer nofollow"';
		                                } else {
		                                    echo ' target="_blank" rel="noopener noreferrer"';
		                                }
		                            } ?>>
		                            <?php
		                            echo '<span class="align-middle">';
		                            echo wp_kses_post( $settings['heading_url_text'] );
		                            echo '</span>';
		                            echo narasix_svg_icon( array( 'icon' => 'arrow-right', 'class' => 'nsix-icon-last' ) );
		                            ?>
		                        </a>
		                    <?php
		                    }
		                    ?>
		                </div>
		            </div>
        <?php
        		echo '</div>';
        	echo '</div>';
        }
	}
}