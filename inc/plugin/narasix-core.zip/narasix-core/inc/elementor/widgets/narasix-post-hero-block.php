<?php
namespace NarasixCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Post_Hero_Block extends Widget_Base {

	use \NarasixCore\Traits\Helper;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'narasix-hero-post-block';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Narasix Hero Post Block', 'narasix-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-group';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'narasix' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'narasix-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		/**
         * Query Controls
         * @source includes/helper.php
         */
        $this->post_query_controls();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Settings', 'narasix-core' ),
			]
		);

		$this->add_control(
			'post_layout',
			[
				'label' => esc_html__( 'Post layout', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'a' => esc_html__( 'Layout 1', 'narasix-core' ),
					'b' => esc_html__( 'Layout 2', 'narasix-core' ),
					'c' => esc_html__( 'Layout 3', 'narasix-core' ),
					'd' => esc_html__( 'Layout 4', 'narasix-core' ),
					'e' => esc_html__( 'Layout 5', 'narasix-core' ),
					'f' => esc_html__( 'Layout 6', 'narasix-core' ),
					'g' => esc_html__( 'Layout 7', 'narasix-core' ),
				],
				'default' => 'a',
			]
		);

		$this->add_control(
			'h_color_prim_setting',
			[
				'label' => __( 'Heading Primary Color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .font-heading' => 'color: {{VALUE}}',
					'{{WRAPPER}} .font-heading' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'a',
						'b',
						'c',
						'd',
						'f',
						'g',
					],
				],
			]
		);

		$this->add_control(
			'h_color_sec_setting',
			[
				'label' => __( 'Heading Secondary Color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .font-heading.secondary' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'a',
						'b',
						'c',
					],
				],
			]
		);

		$this->add_control(
			'numb_color_setting',
			[
				'label' => __( 'Heading Number Color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .numb' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'g'
					],
				],
			]
		);

		$this->add_control(
			'd_color_prim_setting',
			[
				'label' => __( 'Descripiton Primary Color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .desciption' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'a',
						'f',
						'g',
					],
				],
			]
		);

		$this->add_control(
			'd_color_sec_setting',
			[
				'label' => __( 'Descripiton Secondary Color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .desciption.secondary' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'a',
				],
			],
			]
		);

		$this->add_control(
			'color_read_prim_setting',
			[
				'label' => __( 'Read More color Primary', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn-animation' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'a',
				],
			],
			]
		);

		$this->add_control(
			'color_read_sec_setting',
			[
				'label' => __( 'Read More color Secondary', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .btn-animation.secondary' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'a',
				],
			],
			]
		);

		$this->add_control(
			'border_color_setting',
			[
				'label' => __( 'Border color Primary', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .border-t' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .slider-navigation .slider-navigation-item:after' => 'background-color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'b',
						'c',
						'd',
						'f',
						'g',
					],
				],
			]
		);
		
		$this->add_control(
			'border_color_sec_setting',
			[
				'label' => __( 'Border color Secondary', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .border-t.secondary' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .first\:pt-0.last\:pb-0.py-3' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .py-2.space-y-2' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'a',
						'b',
						'c',
					],
				],
			]
		);

		$this->add_control(
			'meta_color_prim_setting',
			[
				'label' => __( 'Meta color Primary', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .font-meta' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'b',
						'c',
						'd',
						'f',
						'g',
					],
				],
			]
		);

		$this->add_control(
			'meta_color_sec_setting',
			[
				'label' => __( 'Meta color Secondary', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .font-meta.secondary' => 'color: {{VALUE}}',
				],
				'condition' => [
					'post_layout' => [
						'b',
						'c',
					],
				],
			]
		);

		$this->add_control(
				'excerpt_length',
				[
						'label' => esc_html__('Excerpt Length', 'narasix-core'),
						'type' => \Elementor\Controls_Manager::NUMBER,
						'min' => 0,
						'max' => 55,
						'default' => 40,
						'title' => esc_html__('In words', 'narasix-core'),
						'condition' => [
							'post_layout' => [
								'a',
								'f',
								'g',
						],
					],
				]
		);

		$this->add_control(
				'excerpt_length_secondary',
				[
						'label' => esc_html__('Excerpt length of secondary posts', 'narasix-core'),
						'type' => \Elementor\Controls_Manager::NUMBER,
						'default' => 20,
						'title' => esc_html__('In words', 'narasix-core'),
						'condition' => [
								'post_layout' => [
									'a',
							],
						],
				]
		);

		$this->add_control(
			'color_setting',
			[
					'label' => __( 'Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#fff',
					'selectors' => [
						'{{WRAPPER}} .e_text-white' => 'color: {{VALUE}}',
						'{{WRAPPER}} .border-t' => 'border-color: {{VALUE}}',
					],
					'condition' => [
						'post_layout' => [
							'e',
					],
				],
			]
		);
		
		$this->add_control(
			'background_setting',
			[
					'label' => __( 'Background', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#353744',
					'selectors' => [
							'{{WRAPPER}} .e_bg-charcoal-700' => 'background-color: {{VALUE}}',
							'{{WRAPPER}} .e_bg-gradient-to-top' => 'background: linear-gradient(to top, {{VALUE}}, #ffffff00)',
							'{{WRAPPER}} .e_bg-gradient-to-left' => 'background: linear-gradient(to left, {{VALUE}}, #ffffff00)',
							'{{WRAPPER}} .e_bg-gradient-to-right' => 'background: linear-gradient(to right, {{VALUE}}, #ffffff00)',
					],
					'condition' => [
						'post_layout' => [
							'e',
					],
				],
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay', 'narasix-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'narasix-core' ),
				'label_off' => esc_html__( 'No', 'narasix-core' ),
				'return_value' => 'yes',
				'default' => 'no',
				'condition' => [
					'post_layout' => 'g',
				],
			]
		);

		$this->add_control(
			'autoplay_speed',
			[
				'label' => esc_html__( 'Autoplay speed', 'narasix-core' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 6000,
				'title' => esc_html__( 'In ms', 'narasix-core' ),
				'conditions' => [
					'relation' => 'and',
					'terms' => [
							[
								'name' => 'autoplay',
								'operator' => '=',
								'value' => 'yes',
							],
							[
								'name' => 'post_layout',
								'operator' => '=',
								'value' => 'g',
							],
						],
				],
			]
		);

		$this->add_control(
			'kenburns',
			[
				'label' => esc_html__( 'Kenburns effect', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'narasix-core' ),
				'label_off' => esc_html__( 'No', 'narasix-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'post_layout' => 'g',
				],
			]
		);

		$this->add_control(
			'readmore_toggle',
			[
					'label' => __( 'Display read more', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'default' => 'yes',
					'label_on' => __( 'Yes', 'narasix-core' ),
					'label_off' => __( 'No', 'narasix-core' ),
					'return_value' => 'yes',
					'condition' => [
						'post_layout' => 'a',
				],
			]
		);

		$this->add_control(
			'read_more_url',
			[
				'label' => esc_html__( 'Heading URL text', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Read more', 'narasix-core' ),
				'condition' => [
					'readmore_toggle' => 'yes',
					'post_layout' => 'a',
				],
			]
		);

		$this->add_control(
			'post_meta_author',
			[
				'label' => __( 'Display author', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'label_on' => __( 'Yes', 'narasix-core' ),
				'label_off' => __( 'No', 'narasix-core' ),
				'return_value' => 'yes',
				'condition' => [
					'post_layout' => [
						'c',
						'd',
						'e',
						'f',
						'g',
					],
				],
			]
		);

		$this->add_control(
			'post_meta_category',
			[
				'label' => __( 'Display category', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'label_on' => __( 'Yes', 'narasix-core' ),
				'label_off' => __( 'No', 'narasix-core' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'post_meta_date',
			[
				'label' => __( 'Display date', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'label_on' => __( 'Yes', 'narasix-core' ),
				'label_off' => __( 'No', 'narasix-core' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'border_radius',
			[
					'label' => __( 'Thumbnail Rounded', 'plugin-name' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors' => [
							'{{WRAPPER}} .rounded_box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .bg-cover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .rounded_b' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} img.wp-post-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		// Get widget settings
		$settings = $this->get_settings_for_display();

		// Create query
        $query_args = $this->narasix_get_query_args( $settings );

		// Create variable to pass to template.
		$template_args = array(
			'query_args' => $query_args,
			'settings' => $settings,
		);

		if ( in_array( $settings['post_layout'], [ 'a', 'b', 'c', 'd', 'e', 'f', 'g'] ) ) {
			narasix_get_template_part( 'template-parts/block/block-hero-post-' . $settings['post_layout'], NULL, $template_args );
		}
	}
}