<?php
namespace NarasixCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Post_Popular extends Widget_Base {

	use \NarasixCore\Traits\Helper;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'narasix-post-popular';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Narasix Block Post Popular', 'narasix-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-counter';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'narasix' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'narasix-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'heading_section',
			[
				'label' => esc_html__( 'Heading', 'narasix-core' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label' => esc_html__( 'Heading', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'subheading',
			[
				'label' => esc_html__( 'Subheading', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'heading_url',
			[
				'label' => esc_html__( 'Heading URL', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::URL,
			]
		);

		$this->add_control(
			'heading_url_text',
			[
				'label' => esc_html__( 'Heading URL text', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'View more', 'narasix-core' ),
			]
		);

		$this->add_control(
			'list_color_control',
			[
					'label' => __( 'List Heading Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#e5e7eb',
					'selectors' => [
							'{{WRAPPER}} .border-l-8' => 'border-color: {{VALUE}};',
					],
			]
		);

		$this->add_control(
			'block_heading_color_control',
			[
					'label' => __( 'Heading Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
							'{{WRAPPER}} .meta-title-block' => 'color: {{VALUE}};',
					],
			]
		);

		$this->add_control(
			'block_read_more_color_control',
			[
					'label' => __( 'Read more Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
							'{{WRAPPER}} .btn-animation' => 'color: {{VALUE}};',
					],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'label' => __( 'Font', 'narasix-core' ),
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .meta-title-block',
			]
		);

		$this->end_controls_section();

		/**
         * Query Controls
         * @source includes/helper.php
         */
        $this->popular_post_query_controls();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Settings', 'narasix-core' ),
			]
		);

		$this->add_control(
			'post_layout',
			[
				'label' => esc_html__( 'Post layout', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'grid' => esc_html__( 'Grid', 'narasix-core' ),
					'carousel' => esc_html__( 'Carousel', 'narasix-core' ),
				],
				'default' => 'carousel',
			]
		);

		$this->add_control(
			'post_style',
			[
				'label' => esc_html__( 'Post style', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'portrait' => esc_html__( 'Default', 'narasix-core' ),
					'card' => esc_html__( 'Card', 'narasix-core' ),
					'cover' => esc_html__( 'cover', 'narasix-core' ),
				],
				'default' => 'portrait',
			]
		);

		$this->add_control(
			'background_setting',
			[
				'label' => __( 'Background color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bg-charcoal-100' => 'background: {{VALUE}}',
				],
				'condition' => [
					'post_style' => [
						'card',
					],
				],
		]
		);

		$this->add_control(
			'h_color_setting',
			[
				'label' => __( 'Heading Color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .font-heading' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'meta_color_setting',
			[
				'label' => __( 'Meta color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .font-meta' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'b_color_setting',
			[
				'label' => __( 'Border Color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .border-t' => 'border-color: {{VALUE}}',
				],
			]
		);

		$this->add_control(
			'background_pn_setting',
			[
				'label' => __( 'Background color Prev/Next', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .button--next' => 'background: linear-gradient(to left, {{VALUE}}, #ffffff00)',
					'{{WRAPPER}} .button--prev' => 'background: linear-gradient(to right, {{VALUE}}, #ffffff00)',
				],
				'condition' => [
					'post_layout' => [
						'carousel',
					],
				],
			]
		);

		$this->add_control(
			'icon_prev_next_color_control',
			[
				'label' => __( 'Icon Prev/Next Color', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
						'{{WRAPPER}} .button--next .icons svg' => 'fill: {{VALUE}};',
						'{{WRAPPER}} .button--prev .icons svg' => 'fill: {{VALUE}};',
				],
				'condition' => [
					'post_layout' => [
						'b',
					],
				],
			]
		);

		$this->add_control(
			'post_meta_author',
			[
				'label' => __( 'Display author', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'label_on' => __( 'Yes', 'narasix-core' ),
				'label_off' => __( 'No', 'narasix-core' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'post_meta_category',
			[
				'label' => __( 'Display category', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'label_on' => __( 'Yes', 'narasix-core' ),
				'label_off' => __( 'No', 'narasix-core' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'post_meta_date',
			[
				'label' => __( 'Display date', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'default' => 'yes',
				'label_on' => __( 'Yes', 'narasix-core' ),
				'label_off' => __( 'No', 'narasix-core' ),
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'border_radius',
			[
					'label' => __( 'Thumbnail Rounded', 'plugin-name' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors' => [
						'{{WRAPPER}} .rounded_box' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						'{{WRAPPER}} .bg-cover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						'{{WRAPPER}} .rounded_b' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						'{{WRAPPER}} img.wp-post-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		// Get widget settings
		$settings = $this->get_settings_for_display();

		// Create query
        $query_args = $this->narasix_get_query_args( $settings );

		// Create variable to pass to template.
		$template_args = array(
			'query_args' => $query_args,
			'settings' => $settings,
		);

        $this->add_render_attribute(
            'post_block_wrapper',
            [
                'id' => 'nsix-elementor-post-popular-' . esc_attr( $this->get_id() ),
                'class' => [
                    'nsix-elementor-post-block',
										'nsix-post-' . esc_attr( $settings['post_layout'] ),
                ],
            ]
        );

        echo '<div ' . $this->get_render_attribute_string( 'post_block_wrapper' ) . '>';
        narasix_get_template_part( 'template-parts/block/block-post-popular-' . $settings['post_layout'], NULL, $template_args );
        echo '</div>';
	}
}