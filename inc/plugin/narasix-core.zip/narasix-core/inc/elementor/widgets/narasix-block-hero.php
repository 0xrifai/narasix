<?php
namespace NarasixCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined("ABSPATH")) {
    exit();
} // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Block_Hero extends Widget_Base
{
    use \NarasixCore\Traits\Helper;

    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name()
    {
        return "narasix-hero";
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title()
    {
        return __("Narasix Hero", "narasix-core");
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon()
    {
        return "eicon-call-to-action";
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories()
    {
        return ["narasix"];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends()
    {
        return ["narasix-core"];
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls()
    {
        $this->start_controls_section("content_section", [
            "label" => esc_html__("Content", "narasix-core"),
        ]);

        $this->add_control("heading", [
            "label" => esc_html__("Heading", "narasix-core"),
            "type" => \Elementor\Controls_Manager::TEXTAREA,
            "label_block" => true,
            "default" => "Welcome to my blog!",
        ]);

        $this->add_control("body", [
            "label" => esc_html__("Body", "narasix-core"),
            "type" => \Elementor\Controls_Manager::WYSIWYG,
            "rows" => 10,
            "default" => esc_html__(
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
                "narasix-core"
            ),
        ]);

        $this->add_control("btn_text", [
            "label" => esc_html__('Button\'s text', "narasix-core"),
            "type" => \Elementor\Controls_Manager::TEXT,
        ]);

        $this->add_control("btn_url", [
            "label" => esc_html__('Button\'s URL', "narasix-core"),
            "type" => \Elementor\Controls_Manager::URL,
            "show_external" => true,
        ]);

        $this->end_controls_section();

        $this->start_controls_section("settings_section", [
            "label" => esc_html__("Settings", "narasix-core"),
        ]);

        $this->add_control("layout", [
            "label" => esc_html__("Layout", "narasix-core"),
            "type" => \Elementor\Controls_Manager::SELECT,
            "options" => [
                "a" => esc_html__("Layout 1", "narasix-core"),
                "b" => esc_html__("Layout 2", "narasix-core"),
            ],
            "default" => "a",
        ]);

        $this->add_control( 'background_setting', [
            'label' => __( 'Background', 'narasix-core' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .bg-blue-600' => 'background-color: {{VALUE}}',
            ],
            "condition" => [
              "layout" => ["b"],
            ],
          ]
        );

        $this->add_control( 'h_color', [
            'label' => __( 'Heading color', 'narasix-core' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .e_heading' => 'color: {{VALUE}}',
            ],
          ]
        );

        $this->add_control( 'des_color', [
            'label' => __( 'Descripiton colors', 'narasix-core' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .e_desc' => 'color: {{VALUE}}',
            ],
          ]
        );

        $this->add_control( 'primary_btn_color', [
            'label' => __( 'Button polor primary', 'narasix-core' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .btn-hero-primary' => 'background-color: {{VALUE}}',
            ],
          ]
        );

        $this->add_control( 'primary_btn_hover_color', [
            'label' => __( 'Button hover color primary', 'narasix-core' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .btn-hero-primary:hover' => 'background-color: {{VALUE}}',
            ],
          ]
        );

        $this->add_control( 'text_btn_color', [
            'label' => __( 'Button text color', 'narasix-core' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .btn-hero-primary' => 'color: {{VALUE}}',
            ],
          ]
        );

        $this->add_control( 'text-hover_btn_color', [
            'label' => __( 'Button hover text color', 'narasix-core' ),
            'type' => \Elementor\Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .btn-hero-primary:hover' => 'color: {{VALUE}}',
            ],
          ]
        );

        $this->add_control("image", [
            "label" => esc_html__("Primary Image", "narasix-core"),
            "type" => \Elementor\Controls_Manager::MEDIA,
            "default" => [
                "url" => \Elementor\Utils::get_placeholder_image_src(),
            ],
            "condition" => [
                "layout" => ["a", "b"],
            ],
        ]);

        $this->add_control("image_secondary", [
            "label" => esc_html__("Secondary Image", "narasix-core"),
            "type" => \Elementor\Controls_Manager::MEDIA,
            "default" => [
                "url" => \Elementor\Utils::get_placeholder_image_src(),
            ],
            "condition" => [
                "layout" => ["b"],
            ],
        ]);

        $this->add_control(
          'border_radius',
          [
              'label' => __( 'Thumbnail Rounded', 'plugin-name' ),
              'type' => \Elementor\Controls_Manager::DIMENSIONS,
              'size_units' => [ 'px', '%' ],
              'selectors' => [
                  '{{WRAPPER}} img.img-hero' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
              ],
          ]
        );
        
        $this->end_controls_section();
    }

    /**
     * Render the widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render()
    {
        // Get widget settings
        $settings = $this->get_settings_for_display();
        // Create query
        $query_args = $this->narasix_get_query_args($settings);

        // Create variable to pass to template.
        $template_args = [
            "query_args" => $query_args,
            "settings" => $settings,
            "section_id" => $this->get_id(),
        ];

        $this->add_render_attribute("about_wrapper", [
            "id" => "nsix-about-" . esc_attr($this->get_id()),

        ]);

        echo "<div " .
            $this->get_render_attribute_string("about_wrapper") .
            ">";
        narasix_get_template_part(
            "template-parts/block/block-hero-" . $settings["layout"],
            null,
            $template_args
        );
        echo "</div>";
    }
}
