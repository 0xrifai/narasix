<?php
namespace NarasixCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Post_Listing extends Widget_Base {

	use \NarasixCore\Traits\Helper;
	// use \NarasixElementor\Template\Posts_Listing;

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'narasix-posts-list';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return esc_html__( 'Narasix Post Listing', 'narasix-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-post-list';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'narasix' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'masonry' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'heading_section',
			[
				'label' => esc_html__( 'Heading', 'narasix-core' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label' => esc_html__( 'Heading', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'subheading',
			[
				'label' => esc_html__( 'Subheading', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->add_control(
			'heading_url',
			[
				'label' => esc_html__( 'Heading URL', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::URL,
			]
		);

		$this->add_control(
			'heading_url_text',
			[
				'label' => esc_html__( 'Heading URL text', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'View more', 'narasix-core' ),
			]
		);

		$this->add_control(
			'block_heading_color_control',
			[
					'label' => __( 'Heading Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
							'{{WRAPPER}} .meta-title-block' => 'color: {{VALUE}};',
					],
			]
		);

		$this->add_control(
			'list_color_control',
			[
					'label' => __( 'List Heading Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '#e5e7eb',
					'selectors' => [
							'{{WRAPPER}} .border-l-8' => 'border-color: {{VALUE}};',
					],
			]
		);

		$this->add_control(
			'block_read_more_color_control',
			[
					'label' => __( 'Read more Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
							'{{WRAPPER}} .btn-animation' => 'color: {{VALUE}};',
					],
			]
		);

		$this->add_control(
			'block_prev_next_color_control',
			[
					'label' => __( 'Heading Color', 'narasix-core' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
							'{{WRAPPER}} .button--next .icons svg' => 'fill: {{VALUE}};',
							'{{WRAPPER}} .button--prev .icons svg,' => 'fill: {{VALUE}};',
					],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'label' => __( 'Font', 'narasix-core' ),
				'name' => 'content_typography',
				'selector' => '{{WRAPPER}} .meta-title-block',
			]
		);

		$this->end_controls_section();

		/**
         * Query And Layout Controls
         * @source includes/helper.php
         */
        $this->post_query_controls();

		$this->start_controls_section(
			'settings_section',
			[
				'label' => esc_html__( 'Settings', 'narasix-core' ),
			]
		);

		$this->add_control(
			'post_layout',
			[
				'label' => esc_html__( 'Post layout', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'list-landscape' => esc_html__( 'List - Landscape', 'narasix-core' ),
					'list-landscape-no-sidebar' => esc_html__( 'List - Landscape - No sidebar', 'narasix-core' ),
					'grid-portrait' => esc_html__( 'Grid - Portrait', 'narasix-core' ),
					'grid-portrait-no-sidebar' => esc_html__( 'Grid - Portrait - No sidebar', 'narasix-core' ),
					'masonry-portrait' => esc_html__( 'Masonry - Portrait', 'narasix-core' ),
				],
				'default' => 'list-landscape',
			]
		);

		$this->sidebar_select_control();

		$this->add_control(
			'grid_columns',
			[
				'label' => esc_html__( 'Mobile display columns', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'1' => esc_html__( '1', 'narasix-core' ),
					'2' => esc_html__( '2', 'narasix-core' ),
				],
				'default' => '1',
				'condition' => [
                    'post_layout' => [
										'grid-portrait',
										'grid-portrait-no-sidebar',
                    ],
                ],
			]
		);

		$this->add_control(
			'post_format_icon',
			[
				'label' => esc_html__( 'Display post format icon', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html( 'Yes', 'narasix' ),
				'label_off' => esc_html( 'No', 'narasix' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

		$this->add_control(
			'excerpt_length_toggle',
			[
				'label' => esc_html__( 'Custom excerpt length', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html( 'Yes', 'narasix' ),
				'label_off' => esc_html( 'No', 'narasix' ),
				'return_value' => 'yes',
				'default' => 'no',
				'conditions' => [
					'relation' => 'or',
					'terms' => [
						[
							'name' => 'post_layout',
							'operator' => 'in',
							'value' => [
								'list-landscape',
								'list-landscape-no-sidebar',
		          ],
		        ],
					],
        ],
			]
		);

		$this->add_control(
				'excerpt_length',
				[
				'label' => esc_html__('Excerpt length', 'narasix-core'),
				'type' => \Elementor\Controls_Manager::NUMBER,
				'min' => 0,
				'max' => 55,
				'step' => 1,
				'default' => 24,
				'title' => esc_html__('In words', 'narasix-core'),
				'conditions' => [
					'relation' => 'and',
					'terms' => [
						[
							'name' => 'excerpt_length_toggle',
		                    'operator' => '===',
		                    'value' => 'yes',
						],
						[
							'relation' => 'or',
							'terms' => [
								[
									'name' => 'post_layout',
									'operator' => 'in',
									'value' => [
									'list-landscape',
									'list-landscape-no-sidebar',
									],
								],      
							],
						],
					],
        ],
      ]
		);

		$this->add_control(
			'pagination',
			[
				'label' => esc_html__( 'Pagination', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'default' => esc_html__( 'Default', 'narasix-core' ),
					'next-and-previous' => esc_html__( 'Next and Previous', 'narasix-core' ),
					'view-more-url' => esc_html__( 'View more URL', 'narasix-core' ),
					'ajax-load-more' => esc_html__( 'Load more', 'narasix-core' ),
					'none' => esc_html__( 'No pagination', 'narasix-core' ),
				],
				'default' => 'default',
			]
		);

		$this->add_control(
			'view_more_url',
			[
				'label' => esc_html__( 'View more URL', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'URL to your archive page', 'narasix-core' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'condition' => [
                    'pagination' => 'view-more-url',
                ],
			]
		);

		$this->add_control(
			'view_more_url_title',
			[
				'label' => esc_html__( 'View more URL title', 'narasix-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'View more', 'narasix-core' ),
				'condition' => [
                    'pagination' => 'view-more-url',
                ],
			]
		);

		$this->add_control(
			'border_radius',
			[
					'label' => __( 'Thumbnail Rounded', 'plugin-name' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors' => [
							'{{WRAPPER}} img.wp-post-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		// Get widget settings
		$settings = $this->get_settings_for_display();
		// Create query
        $query_args = $this->narasix_get_query_args( $settings );

		// Create variable to pass to template.
		$template_args = array(
			'query_args' => $query_args,
			'settings' => $settings,
		);

        $this->add_render_attribute(
            'post_listing_wrapper',
            [
                'id' => 'nsix-post-listing-' . esc_attr( $this->get_id() ),
                'class' => [
                    'nsix-post-listing',
                    'nsix-post-listing-' . esc_attr( $settings['post_layout'] ),
                ],
            ]
        );

        echo '<div ' . $this->get_render_attribute_string( 'post_listing_wrapper' ) . '>';
        narasix_get_template_part( 'template-parts/block/block-listing', NULL, $template_args );
        echo '</div>';
	}
}