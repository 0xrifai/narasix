<?php
namespace NarasixCore;

/**
 * Class Elementor Plugin
 *
 * Elementor Plugin class
 * @since 1.0.0
 */
class Elementor_Plugin {

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 * @access private
	 * @static
	 *
	 * @var Plugin The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return Plugin An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * widget_scripts
	 *
	 * Load required plugin core files.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function widget_scripts() {
		// wp_register_script( 'narasix-core', plugins_url( '/assets/js/hello-world.js', __FILE__ ), [ 'jquery' ], false, true );
	}

	/**
	 * Include Widgets files
	 *
	 * Load widgets files
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function include_widgets_files() {
		require_once( __DIR__ . '/widgets/narasix-block-heading.php' );
		require_once( __DIR__ . '/widgets/narasix-block-hero.php' );
		require_once( __DIR__ . '/widgets/narasix-post-hero-block.php' );
		require_once( __DIR__ . '/widgets/narasix-post-block.php' );
		require_once( __DIR__ . '/widgets/narasix-post-carousel.php' );
		require_once( __DIR__ . '/widgets/narasix-post-listing.php' );
		require_once( __DIR__ . '/widgets/narasix-post-popular.php' );
	}

	/**
	 * Register Widgets
	 *
	 * Register new Elementor widgets.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function register_widgets() {
		// Its is now safe to include Widgets files
		$this->include_widgets_files();

		// Register Widgets
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Block_heading() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Block_Hero() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Post_Hero_Block() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Post_Block() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Post_Listing() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Post_Carousel() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Widgets\Post_Popular() );
	}

	/**
	 * Include files
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function include_files() {
		// Include helper file
		require_once( __DIR__ . '/includes/helper.php' );
	}

	/**
	 * Plugin class constructor
	 *
	 * Register plugin action hooks and filters
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {

		// Register widget scripts
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'widget_scripts' ] );

		// Register widgets
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );

		self::include_files();
	}
}

// Instantiate Plugin Class
Elementor_Plugin::instance();