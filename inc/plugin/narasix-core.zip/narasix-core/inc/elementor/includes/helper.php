<?php
namespace NarasixCore\Traits;

if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly

use \Elementor\Controls_Manager;
use \Elementor\Group_Control_Border;
use \Elementor\Group_Control_Box_Shadow;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Group_Control_Typography;
use \Elementor\Utils;

trait Helper {
    /**
     * Get all types of post.
     * @return array
     */
    public function narasix_get_all_types_post()
    {
        $posts = get_posts([
            'post_type' => 'any',
            'post_style' => 'all_types',
            'post_status' => 'publish',
            'posts_per_page' => '-1',
        ]);

        if (!empty($posts)) {
            return wp_list_pluck($posts, 'post_title', 'ID');
        }

        return [];
    }

    /**
     * Sidebar Select Controls
     *
     */
    protected function sidebar_select_control() {
        global $wp_registered_sidebars;

        $options = [];

        if ( ! $wp_registered_sidebars ) {
            $options[''] = esc_html__( 'No sidebars were found', 'narasix-core' );
        } else {
            $options[''] = esc_html__( 'Choose sidebar', 'narasix-core' );

            foreach ( $wp_registered_sidebars as $sidebar_id => $sidebar ) {
                $options[ $sidebar_id ] = $sidebar[ 'name' ];
            }
        }

        $default_key = array_keys( $options );
        $default_key = array_shift( $default_key );

        $control_args = [
            'label' => esc_html__( 'Sidebar', 'narasix-core' ),
            'type' => Controls_Manager::SELECT,
            'default' => $default_key,
            'options' => $options,
        ];

        if ( $this->get_name() === 'narasix-posts-list' ) {
            $control_args['condition'] = [
                'post_layout' => [
                    'list-landscape',
                    'grid-portrait',
                    'mixed-a',
                    'mixed-b',
                    'masonry-portrait',
                ],
            ];
        }

        $this->add_control(
            'sidebar',
            $control_args
        );
    }

    /**
     * Query Controls
     *
     */
    protected function post_query_controls() {
        $post_types = $this->narasix_get_post_types();
        $post_types[ 'by_id' ] = __( 'Manual Selection', 'narasix-core' );
        $taxonomies = get_taxonomies( [], 'objects' );

        $this->start_controls_section(
            'query_section',
            [
                'label' => __( 'Query', 'narasix-core' ),
            ]
        );

        $this->add_control(
            'post_type',
            [
                'label' => __( 'Source', 'narasix-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => $post_types,
                'default' => key( $post_types ),
            ]
        );

        $this->add_control(
            'select_by',
            [
                'label' => esc_html__( 'Select by', 'narasix-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'name' => esc_html__( 'Name', 'narasix-core' ),
                    'id' => esc_html__( 'ID', 'narasix-core' ),
                ],
                'default' => 'name',
                'condition' => [
                    'post_type' => 'by_id',
                ],
            ]
        );

        $this->add_control(
            'post_ids_name',
            [
                'label' => __('Search & Select', 'narasix-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => $this->narasix_get_all_types_post(),
                'label_block' => true,
                'multiple' => true,
                'condition' => [
                    'post_type' => 'by_id',
                    'select_by' => 'name',
                ],
            ]
        );

         $this->add_control(
            'post_ids',
            [
                'label' => esc_html__( 'Post ID list', 'narasix-core' ),
                'description' => esc_html__( 'IDs of posts, separated by ",". You can check the IDs of your posts', 'narasix-core' ) . ' <a href="' . esc_url( admin_url( 'edit.php' ) ) . '"> ' . esc_html__( 'here', 'narasix-core' ) . ' </a> ',
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'post_type' => 'by_id',
                    'select_by' => 'id',
                ],
            ]
        );

        $this->add_control(
            'authors', [
                'label' => __('Author', 'narasix-core'),
                'label_block' => true,
                'type' => Controls_Manager::SELECT2,
                'multiple' => true,
                'default' => [],
                'options' => $this->get_authors(),
                'condition' => [
                    'post_type!' => 'by_id',
                ],
            ]
        );

        foreach ($taxonomies as $taxonomy => $object) {
            if (!in_array($object->object_type[0], array_keys($post_types))) {
                continue;
            }

            $this->add_control(
                $taxonomy . '_ids',
                [
                    'label' => $object->label,
                    'type' => Controls_Manager::SELECT2,
                    'label_block' => true,
                    'multiple' => true,
                    'object_type' => $taxonomy,
                    'options' => wp_list_pluck( get_terms( $taxonomy ), 'name', 'term_id' ),
                    'condition' => [
                        'post_type' => $object->object_type,
                    ],
                ]
            );
        }

        $this->add_control(
            'post__not_in',
            [
                'label' => __('Exclude', 'narasix-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => $this->narasix_get_all_types_post(),
                'label_block' => true,
                'post_type' => '',
                'multiple' => true,
                'default' => [],
                'condition' => [
                    'post_type!' => 'by_id',
                ],
            ]
        );

        if ( $this->get_name() === 'narasix-posts-list' ) {
            $this->add_control(
                'posts_per_page',
                [
                    'label' => __('Number of posts', 'narasix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                ]
            );
        } elseif ( $this->get_name() === 'narasix-post-slider' ) {
            $this->add_control(
                'posts_per_page',
                [
                    'label' => __('Number of posts', 'narasix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                ]
            );
        } elseif ( $this->get_name() === 'narasix-post-carousel' ) {
            $this->add_control(
                'posts_per_page',
                [
                    'label' => __('Number of posts', 'narasix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => 4,
                ]
            );
        }

        $this->add_control(
            'offset',
            [
                'label' => __('Offset', 'narasix-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 0,
                'condition' => [
                    'post_type!' => 'by_id',
                    'orderby!' => 'post__in',
                ],
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => __('Order by', 'narasix-core'),
                'description' => esc_html__( 'Order by ID list only available when selecting posts by IDs', 'narasix-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => $this->get_post_orderby_options(),
                'default' => 'date',

            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __('Order', 'narasix-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'asc' => 'Ascending',
                    'desc' => 'Descending',
                ],
                'default' => 'desc',
                'condition' => [
                    'select_by!' => 'id',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Query Controls for Popular Posts
     *
     */
    protected function popular_post_query_controls() {
        $post_types = $this->narasix_get_post_types();
        $post_types['by_id'] = esc_html__( 'Manual Selection', 'narasix-core' );
        $taxonomies = get_taxonomies( [], 'objects' );

        $this->start_controls_section(
            'query_section',
            [
                'label' => esc_html__( 'Query', 'narasix-core' ),
            ]
        );

        $this->add_control(
            'post_type',
            [
                'label' => esc_html__( 'Source', 'narasix-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'post' => esc_html__( 'Post', 'narasix-core' ),
                    'by_id' => esc_html__( 'Manual Selection', 'narasix-core' ),
                ],
                'default' => 'post',
            ]
        );

        $this->add_control(
            'select_by',
            [
                'label' => esc_html__( 'Select by', 'narasix-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'name' => esc_html__( 'Name', 'narasix-core' ),
                    'id' => esc_html__( 'ID', 'narasix-core' ),
                ],
                'default' => 'name',
                'condition' => [
                    'post_type' => 'by_id',
                ],
            ]
        );

        $this->add_control(
            'post_ids_name',
            [
                'label' => __('Search & Select', 'narasix-core'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'options' => $this->narasix_get_all_types_post(),
                'label_block' => true,
                'multiple' => true,
                'condition' => [
                    'post_type' => 'by_id',
                    'select_by' => 'name',
                ],
            ]
        );

         $this->add_control(
            'post_ids',
            [
                'label' => esc_html__( 'Post ID list', 'narasix-core' ),
                'description' => esc_html__( 'IDs of posts, separated by ",". You can check the IDs of your posts', 'narasix-core' ) . ' <a href="' . esc_url( admin_url( 'edit.php' ) ) . '"> ' . esc_html__( 'here', 'narasix-core' ) . ' </a> ',
                'type' => \Elementor\Controls_Manager::TEXT,
                'condition' => [
                    'post_type' => 'by_id',
                    'select_by' => 'id',
                ],
            ]
        );

        $this->add_control(
            'authors', [
                'label' => esc_html__( 'Author', 'narasix-core' ),
                'label_block' => true,
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'default' => [],
                'options' => $this->get_authors(),
                'condition' => [
                    'post_type!' => 'by_id',
                ],
            ]
        );

        foreach ( $taxonomies as $taxonomy => $object ) {
            if ( !in_array( $object->object_type[0], array_keys( $post_types ) ) ) {
                continue;
            }

            // Skip post format control.
            if ( $taxonomy === 'post_format' ) {
                continue;
            }

            $this->add_control(
                $taxonomy . '_ids',
                [
                    'label' => $object->label,
                    'type' => \Elementor\Controls_Manager::SELECT2,
                    'label_block' => true,
                    'multiple' => true,
                    'object_type' => $taxonomy,
                    'options' => wp_list_pluck( get_terms( $taxonomy ), 'name', 'term_id' ),
                    'condition' => [
                        'post_type' => $object->object_type,
                    ],
                ]
            );
        }

        $this->add_control(
            'post__not_in',
            [
                'label' => __('Exclude', 'narasix-core'),
                'type' => Controls_Manager::SELECT2,
                'options' => $this->narasix_get_all_types_post(),
                'label_block' => true,
                'multiple' => true,
                'default' => [],
                'condition' => [
                    'post_type!' => 'by_id',
                ],
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Number of posts', 'narasix-core'),
                'type' => Controls_Manager::NUMBER,
                'default' => 4,
            ]
        );

        $this->add_control(
            'offset',
            [
                'label' => __('Offset', 'narasix-core'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 0,
                'condition' => [
                    'post_type!' => 'by_id',
                    'orderby!' => [
                        'post__in',
                        'wpp',
                    ],
                ],
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => __('Order by', 'narasix-core'),
                'description' => esc_html__( 'Order by ID list only available when selecting posts by IDs', 'narasix-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'ID' => esc_html__( 'Post ID', 'narasix-core' ),
                    'author' => esc_html__( 'Post author', 'narasix-core' ),
                    'title' => esc_html__( 'Title', 'narasix-core' ),
                    'date' => esc_html__( 'Date', 'narasix-core' ),
                    'modified' => esc_html__( 'Last modified date', 'narasix-core' ),
                    'parent' => esc_html__( 'Parent ID', 'narasix-core' ),
                    'rand' => esc_html__( 'Random', 'narasix-core' ),
                    'comment_count' => esc_html__( 'Comment count', 'narasix-core' ),
                    'menu_order' => esc_html__( 'Menu order', 'narasix-core' ),
                    'post__in' => esc_html__( 'ID list', 'narasix-core' ),
                    'wpp' => esc_html__( 'WordPress Popular Posts plugin', 'narasix-core' ),
                ],
                'default' => 'date',
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => esc_html__('Order', 'narasix-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'asc' => 'Ascending',
                    'desc' => 'Descending',
                ],
                'default' => 'desc',
                'condition' => [
                    'select_by!' => 'id',
                    'orderby!' => 'wpp',
                ],
            ]
        );

        // WPP parameters.
        $this->add_control(
            'order_by',
            [
                'label' => esc_html__( 'Sort posts by', 'narasix-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'views' => esc_html__( 'Total views', 'narasix-core' ),
                    'avg' => esc_html__( 'Average daily views', 'narasix-core' ),
                ],
                'default' => 'views',
                'condition' => [
                    'orderby' => 'wpp',
                ],
            ]
        );

        $this->add_control(
            'range',
            [
                'label' => esc_html__( 'Time range', 'narasix-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'last24hours' => esc_html__( 'Last 24 hours', 'narasix-core' ),
                    'last7days' => esc_html__( 'Last 7 days', 'narasix-core' ),
                    'last30days' => esc_html__( 'Last 30 days', 'narasix-core' ),
                    'all' => esc_html__( 'All time', 'narasix-core' ),
                    'custom' => esc_html__( 'Custom', 'narasix-core' ),
                ],
                'default' => 'all',
                'condition' => [
                    'orderby' => 'wpp',
                ],
            ]
        );

        $this->add_control(
            'time_quantity',
            [
                'label' => esc_html__('Custome time range value', 'narasix-core'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 0,
                'default' => 24,
                'condition' => [
                    'orderby' => 'wpp',
                    'range' => 'custom',
                ],
            ]
        );

        $this->add_control(
            'time_unit',
            [
                'label' => esc_html__( 'Custom time range unit', 'narasix-core' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'minute' => esc_html__( 'minute', 'narasix-core' ),
                    'hour' => esc_html__( 'hour', 'narasix-core' ),
                    'day' => esc_html__( 'day', 'narasix-core' ),
                    'week' => esc_html__( 'week', 'narasix-core' ),
                    'month' => esc_html__( 'month', 'narasix-core' ),
                ],
                'default' => 'hour',
                'condition' => [
                    'orderby' => 'wpp',
                    'range' => 'custom',
                ],
            ]
        );

        $this->add_control(
            'freshness',
            [
                'label' => esc_html__( 'Posts within Time range', 'narasix-core' ),
                'description' => esc_html__( 'Display only posts published within the selected Time range', 'narasix-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html( 'Yes', 'narasix' ),
                'label_off' => esc_html( 'No', 'narasix' ),
                'return_value' => 'yes',
                'default' => 'no',
                'condition' => [
                    'orderby' => 'wpp',
                ],
            ]
        );

        $this->end_controls_section();
    }

    public function narasix_get_query_args( $settings = [] ) {

        // Merge with default args
        $settings = wp_parse_args( $settings, array(
            'post_type' => 'post',
            'select_by' => '',
            'post_ids' => [],
            'orderby' => 'date',
            'order' => 'desc',
            'posts_per_page' => 3,
            'offset' => 0,
            'post__not_in' => [],
            'no_found_rows' => true,
        ) );

        if ( $settings['select_by'] === 'name' ) {
            $settings['post_ids'] = $settings['post_ids_name'];
        } elseif ( $settings['post_ids'] ) {
            $settings['post_ids'] = explode( ',', $settings['post_ids'] );
        } else {
            $post_ids = [];
        }

        if ( ( $settings['select_by'] === 'id' ) && ( $settings['orderby'] === 'post__in' ) ) {
            $settings['order'] = 'asc';
        }

        $args = [
            'orderby' => $settings['orderby'],
            'order' => $settings['order'],
            'ignore_sticky_posts' => 1,
            'post_status' => 'publish',
            'posts_per_page' => $settings['posts_per_page'],
            'offset' => $settings['offset']
        ];

        if ( 'by_id' === $settings['post_type'] ) {
            $args['post_type'] = array( 'post', 'page' );
            $args['post__in'] = empty( $settings['post_ids'] ) ? [0] : $settings['post_ids'];
        } else {
            $args['post_type'] = $settings['post_type'];
            $args['tax_query'] = [];

            $taxonomies = get_object_taxonomies( $settings['post_type'], 'objects' );

            foreach ( $taxonomies as $object ) {
                $setting_key = $object->name . '_ids';

                if ( !empty( $settings[$setting_key] ) ) {
                    $args['tax_query'][] = [
                        'taxonomy' => $object->name,
                        'field' => 'term_id',
                        'terms' => $settings[$setting_key],
                    ];
                }
            }

            if ( count( $args['tax_query'] ) > 1 ) {
                $args['tax_query']['relation'] = 'OR';
            }
        }

        if ( !empty($settings['authors']) ) {
            $args['author__in'] = $settings['authors'];
        }

        if ( !empty($settings['post__not_in']) ) {
            $args['post__not_in'] = $settings['post__not_in'];
        }

        return $args;
    }

    /**
     * Get All Post Types
     * @return array
     */
    public function narasix_get_post_types()
    {
        $post_types = get_post_types( ['public' => true, 'show_in_nav_menus' => true], 'objects' );
        $post_types = wp_list_pluck($post_types, 'label', 'name');

        return array_diff_key( $post_types, ['elementor_library', 'attachment'] );
    }

    /**
     * Get Post Thumbnail Size
     *
     * @return array
     */
    public function get_thumbnail_sizes()
    {
        $sizes = get_intermediate_image_sizes();
        foreach ($sizes as $s) {
            $ret[$s] = $s;
        }

        return $ret;
    }

    /**
     * POst Orderby Options
     *
     * @return array
     */
    public function get_post_orderby_options()
    {
        $orderby = array(
            'ID' => esc_html__( 'Post ID', 'narasix-core' ),
            'author' => esc_html__( 'Post author', 'narasix-core' ),
            'title' => esc_html__( 'Title', 'narasix-core' ),
            'date' => esc_html__( 'Date', 'narasix-core' ),
            'modified' => esc_html__( 'Last modified date', 'narasix-core' ),
            'parent' => esc_html__( 'Parent ID', 'narasix-core' ),
            'rand' => esc_html__( 'Random', 'narasix-core' ),
            'comment_count' => esc_html__( 'Comment count', 'narasix-core' ),
            'menu_order' => esc_html__( 'Menu order', 'narasix-core' ),
            'post__in' => esc_html__( 'ID list', 'narasix-core' ),
        );

        return $orderby;
    }

    /**
     * Get Post Categories
     *
     * @return array
     */
    public function get_categories( $type = 'term_id' )
    {
        $terms = get_terms( array(
            'taxonomy' => 'category',
            'hide_empty' => true,
        ) );

        if ( !empty( $terms ) && !is_wp_error( $terms ) ) {
            foreach ( $terms as $term ) {
                $options[$term->{$type}] = $term->name;
            }
        }

        return $options;
    }

    /**
     * Get all elementor page templates
     *
     * @return array
     */
    public function get_page_templates($type = null)
    {
        $args = [
            'post_type' => 'elementor_library',
            'posts_per_page' => -1,
        ];

        if ($type) {
            $args['tax_query'] = [
                [
                    'taxonomy' => 'elementor_library_type',
                    'field' => 'slug',
                    'terms' => $type,
                ],
            ];
        }

        $page_templates = get_posts($args);
        $options = array();

        if (!empty($page_templates) && !is_wp_error($page_templates)) {
            foreach ($page_templates as $post) {
                $options[$post->ID] = $post->post_title;
            }
        }
        return $options;
    }

    /**
     * Get all Authors
     *
     * @return array
     */
    public function get_authors()
    {
        $args = array(
            'capability' => array( 'edit_posts' ),
            'has_published_posts' => true,
            'fields' => [
                'ID',
                'display_name',
            ],
        );
         
        // Capability queries were only introduced in WP 5.9.
        if ( version_compare( $GLOBALS['wp_version'], '5.9', '<' ) ) {
            $args['who'] = 'authors';
            unset( $args['capability'] );
        }
 
        $users = get_users( $args );

        if ( !empty( $users) ) {
            return wp_list_pluck( $users, 'display_name', 'ID' );
        }

        return [];
    }

    /**
     * Get all Tags
     *
     * @return array
     */
    public function get_tags()
    {
        $options = array();
        $tags = get_tags();

        foreach ($tags as $tag) {
            $options[$tag->term_id] = $tag->name;
        }

        return $options;
    }

    /**
     * Get all Posts
     *
     * @return array
     */
    public function get_posts()
    {
        $post_list = get_posts(array(
            'post_type' => 'post',
            'orderby' => 'date',
            'order' => 'DESC',
            'posts_per_page' => -1,
        ));

        $posts = array();

        if (!empty($post_list) && !is_wp_error($post_list)) {
            foreach ($post_list as $post) {
                $posts[$post->ID] = $post->post_title;
            }
        }

        return $posts;
    }

    /**
     * Get all Pages
     *
     * @return array
     */
    public function get_pages()
    {
        $page_list = get_posts(array(
            'post_type' => 'page',
            'orderby' => 'date',
            'order' => 'DESC',
            'posts_per_page' => -1,
        ));

        $pages = array();

        if (!empty($page_list) && !is_wp_error($page_list)) {
            foreach ($page_list as $page) {
                $pages[$page->ID] = $page->post_title;
            }
        }

        return $pages;
    }

    /**
     * Backwards compability for get_template_part()
     */
    public function narasix_get_template_part( $slug, $name = NULL, $args = array() ) {
        // Check if current version of WordPress is later than 5.5
        if ( get_bloginfo( 'version' ) >= '5.5' ) {
            get_template_part( $slug, $name, $args );
        } else {
            set_query_var( 'args', $args );
            get_template_part( $slug, $name, $args );
            set_query_var( 'args', false );
        }
    }
}